self.assetsManifest = {
  "version": "CxLz98CV",
  "assets": [
    {
      "hash": "sha256-l5BDvd+twgQNqtVVKIE1Xwy1mWTPtT6zwVL9Npy7Uqs=",
      "url": "BlHell-per.styles.css"
    },
    {
      "hash": "sha256-xIq0ustLrUFLaAS+c/Lq2ebq/D+LIkopuBXo2P9peAI=",
      "url": "Pages/Constructor.razor.js"
    },
    {
      "hash": "sha256-PtApvXsjtN3h6TrGmJjCQsaFMN/pyLARBUCEQhLn7Oc=",
      "url": "_content/BlazorDownloadFile/BlazorDownloadFileScript.js"
    },
    {
      "hash": "sha256-yP1oDpITnnprhJSP8GwxKos+H7isHghi8z/WPwb7vjw=",
      "url": "_content/MathJaxBlazor/mathJaxBlazor.js"
    },
    {
      "hash": "sha256-pHQzgXyCkSiUP/NNL86ZMhhLQlyRDbUg/KM2cH0Looo=",
      "url": "_content/MathJaxBlazor/mathJaxBlazor.js.map"
    },
    {
      "hash": "sha256-Hh7BRmiYuRD1Lq8ZF9jVWOOJuN3tWPS5M2lLZzuayjw=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-weSY1+xC2IWsc4ncUHtQhWp3H5eek/LVHZEDlWdgryY=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-yEpb3vXc7l7/qmiEWUNfWHN9EnLRY7PddqDP9utPlpg=",
      "url": "_content/Toolbelt.Blazor.FileDropZone/script.min.js"
    },
    {
      "hash": "sha256-rN9ebccf1yzi+bWyyip51JJuAKONWUHDBKWnKUpDWAA=",
      "url": "_content/Toolbelt.Blazor.GetProperty.Script/Toolbelt.Blazor.GetProperty.Script.lib.module.js"
    },
    {
      "hash": "sha256-CK+dWt+OnOJk5VwBqtsmkDE+aiT775AOXXJRLf/3Gao=",
      "url": "_framework/BlHell-per.8c190shxj5.wasm"
    },
    {
      "hash": "sha256-YB8HlaKSU6hGhkiMwSSlwRa4MDljnOAAmxBFTAqQWes=",
      "url": "_framework/BlazorDownloadFile.ct05c4bfyq.wasm"
    },
    {
      "hash": "sha256-EXpYXqugNJtp1u5qnDKMDRhx03gSsum4RJdciSdjvh4=",
      "url": "_framework/MathJaxBlazor.p6ulmaf7ls.wasm"
    },
    {
      "hash": "sha256-iLxTio+CuXrAVvHl7FWdAuLaq5Imu8rSOJ6hzxQhRmk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.gqka07kwp7.wasm"
    },
    {
      "hash": "sha256-9LH5dSWW+Kx1mEdr0EPTInzIrgUi9bU/bTAm4vHsHv8=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.wd827pb4ol.wasm"
    },
    {
      "hash": "sha256-wkcm++Lk6tpwju7d/7A/Rjhj7l5V/LWWaQhx3DHgdh8=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.u9mc0juxx6.wasm"
    },
    {
      "hash": "sha256-RfxcwkhdKAtSQ+QMq3hcjN+qwIF4HUcqJnvOpDPnIEA=",
      "url": "_framework/Microsoft.AspNetCore.Components.tuz7b84wsu.wasm"
    },
    {
      "hash": "sha256-GjI9vkQKnVxmTLe8o7kZYAwFxKE0/UQnSKrzxuXGAsQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.u3l5g6tuv0.wasm"
    },
    {
      "hash": "sha256-FQjLsQaz4KTpgQKQkcTn5A5IuUgcYT6MpYuBsN/vjX0=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.7d9a22amlg.wasm"
    },
    {
      "hash": "sha256-kizMyczNs6pFkLVfw3WQsZxAo/8HgmtiDuHyKMQLmpA=",
      "url": "_framework/Microsoft.Extensions.Configuration.iclqaprdn6.wasm"
    },
    {
      "hash": "sha256-m76cRGDZrbFBny6QPvuX22CiDKM8TUNnWv/U7bjWO1o=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.vzxqs9j4l4.wasm"
    },
    {
      "hash": "sha256-MOVlPkeO9+8Nu3CBHZqiF9YgpspbjBuCIS4K9LqliPs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.clr2lmubvg.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-DFmtrnKYzzerBuR5f43sd/+DpUnvSV+FBOLJQEBLWK8=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.0prz4zc256.wasm"
    },
    {
      "hash": "sha256-0PwVT3DJI3W4JqGJbzbuXm7Z6pEsGxwIJp8zWaidzJw=",
      "url": "_framework/Microsoft.Extensions.Logging.g06jewh4ge.wasm"
    },
    {
      "hash": "sha256-j6OzRkwAr6dRtI5CnnoLZ8YvU/+xUW3BkehrQWeZzCA=",
      "url": "_framework/Microsoft.Extensions.Options.7exurhso5d.wasm"
    },
    {
      "hash": "sha256-94QoZadgwzeiFIU+yLaR2X8Nu3IA4MJHyHNo3rfcep8=",
      "url": "_framework/Microsoft.Extensions.Primitives.xuv72fcd9m.wasm"
    },
    {
      "hash": "sha256-WuuQXW1+AnPHafZKt7ukqmwRDrGYbEV2LhxNuPl+ybo=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.y1ydbrr1bj.wasm"
    },
    {
      "hash": "sha256-nvGGypprybtKTICn6+vbklsAYvogZU55KKo7Zd4Trto=",
      "url": "_framework/Microsoft.JSInterop.ijy7jdc5cu.wasm"
    },
    {
      "hash": "sha256-GlOHQWO8wIWEit9nY0lW4eZrXEf1rWuEtcLra6t53GM=",
      "url": "_framework/MudBlazor.ytj6fxnkt8.wasm"
    },
    {
      "hash": "sha256-DJdDTXvakyNHX4h3BiAA4J8FvqYQINUrHsyNTCNihFc=",
      "url": "_framework/System.Collections.Concurrent.4e1s9e43lu.wasm"
    },
    {
      "hash": "sha256-5FtcbEdtWLXjTKmJnrEgjPwc4AeM9KYAtdJfJlE/HA0=",
      "url": "_framework/System.Collections.Immutable.otn27avgt8.wasm"
    },
    {
      "hash": "sha256-xRIMDk69wz0R2zXZTCyiwwisoHRSQ+OeAIc0JHv9ZZI=",
      "url": "_framework/System.Collections.NonGeneric.dyzfblxpyw.wasm"
    },
    {
      "hash": "sha256-P5jA//Zgh2W/Utp/ZpigFhlwVkS6/jvZDRyDVTxUk8A=",
      "url": "_framework/System.Collections.Specialized.dt26wtuqcc.wasm"
    },
    {
      "hash": "sha256-lVTRFLTCCnhr0PpBt06qHRqlXlBkv7du6By4L0OdKdQ=",
      "url": "_framework/System.Collections.tizvj7i0uj.wasm"
    },
    {
      "hash": "sha256-JbHLj8j/f2l2Pa1qzHHO/RhVkjqVVkaQQxu1jwX79f0=",
      "url": "_framework/System.ComponentModel.Annotations.lkwdjajhg8.wasm"
    },
    {
      "hash": "sha256-fSDdLVuurF4KRxCI23u4BzMawtdrQpQnfs6T14zkAM0=",
      "url": "_framework/System.ComponentModel.Primitives.d0b71bcams.wasm"
    },
    {
      "hash": "sha256-t+/vDkOuT6H/jPmlh76lwEyK41EYZyuWK8g2CoUVMrI=",
      "url": "_framework/System.ComponentModel.TypeConverter.l9r10orze6.wasm"
    },
    {
      "hash": "sha256-R7ngh95V/nsqhrCHW2rk39aNArmqdfwpXE4RTI+u4Kk=",
      "url": "_framework/System.ComponentModel.fmqia21jk3.wasm"
    },
    {
      "hash": "sha256-dGy2lo5gnpaqroAz+Ee7cpkxe2OdwHcgZ0uNMH1n/Ro=",
      "url": "_framework/System.Console.gfqrhpaqb1.wasm"
    },
    {
      "hash": "sha256-4bnlO6XiYz+e/K/WP2JAzRWaEc1oDm+/FedNs3BLZ/s=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.bds6p6ewyu.wasm"
    },
    {
      "hash": "sha256-d4Fv2UP7j+pqOrhljw06Xjdf1UB0VVgcWQAZYM+e2Ak=",
      "url": "_framework/System.IO.Pipelines.3p3f5vckx6.wasm"
    },
    {
      "hash": "sha256-6mENfn51o1yEQT+fI0TI31X9SSUSOJ6hbGnLMaGvC3s=",
      "url": "_framework/System.Linq.Expressions.2l6v3u1dsj.wasm"
    },
    {
      "hash": "sha256-GszUvm0NkWNHOftI4R13DzpIZJpz87TVI34oCuulDNA=",
      "url": "_framework/System.Linq.m51dx9kvbz.wasm"
    },
    {
      "hash": "sha256-wy2EU9j5x+FTuhiwP8UqFcKkiwVBxA9lq45vLjqQo6w=",
      "url": "_framework/System.Memory.z4lrm545w5.wasm"
    },
    {
      "hash": "sha256-V6TNXhuZhlRU6A9LV0J2nSnl2/p1zAQ2QR30a2Fyu8c=",
      "url": "_framework/System.Net.Http.Json.rjh6ihdw3m.wasm"
    },
    {
      "hash": "sha256-YY+9zV/XTBNYuMNjrgxGf1sQqeOkrFsDgdS+nmepcco=",
      "url": "_framework/System.Net.Http.hg5vu5ht4o.wasm"
    },
    {
      "hash": "sha256-5jS6wHg5BUfY2FckWbpdn75sOjWbxL6YA0gKEgWpUq8=",
      "url": "_framework/System.Net.Primitives.6p59uqgnlv.wasm"
    },
    {
      "hash": "sha256-UMnsYsDhkVRyHjqIs+0nmkByCrytfJZyGMee41XvSbo=",
      "url": "_framework/System.ObjectModel.slc2t06m86.wasm"
    },
    {
      "hash": "sha256-e8RVpKjRx+ESMn0p1dcoXf8l3ExuXbjCVmP8Mv1/dmw=",
      "url": "_framework/System.Private.CoreLib.vvoufncklt.wasm"
    },
    {
      "hash": "sha256-YcmEal+ihQHGK8EMiAtOZYn8QNTceGY84JEIEpaHbTk=",
      "url": "_framework/System.Private.Uri.j3aalcg4sl.wasm"
    },
    {
      "hash": "sha256-92zUoi9qwW2rZalWHIYTUNdUv+uUJLg6ZLS4Aj0eqHk=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.5pcrya9j00.wasm"
    },
    {
      "hash": "sha256-yDhWCgjkym3pOgGmGDBvhDQ+ay4ban8fwy2PHgy9ZJc=",
      "url": "_framework/System.Runtime.Serialization.Primitives.0izij8z8z3.wasm"
    },
    {
      "hash": "sha256-effku/n3YAOJAbaxORStl9ojHRSRIBkKJhZPNpBb7ws=",
      "url": "_framework/System.Runtime.vurirw7n4s.wasm"
    },
    {
      "hash": "sha256-n9kLQ/k8kXl3t2LT/e+IZ9uQuVqD4liLTfriaUr7X2g=",
      "url": "_framework/System.Text.Encodings.Web.zj13rhh3ea.wasm"
    },
    {
      "hash": "sha256-6x5KFwZqBD5HHDpSB/Bv/jo0ICPjwBjwFQP4QTtmCfo=",
      "url": "_framework/System.Text.Json.zuxa1157rx.wasm"
    },
    {
      "hash": "sha256-EXB0ovz6ajs+MOv1iMeZ7Xyn6CrhdLJNGfNigKK9fYI=",
      "url": "_framework/System.Text.RegularExpressions.5n5al0wk87.wasm"
    },
    {
      "hash": "sha256-ViNRvhyxlTugIlqJHamw/HwbXlg/YWcrANmxuTM0tfg=",
      "url": "_framework/System.ezrw3d5kw2.wasm"
    },
    {
      "hash": "sha256-O6Z3wKd6ME+Fzh+ha+TvVMDGZJnJfxm3VZ/wI1cHZ8g=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-0C5th70x3cgwI6otbYfnZFNKiDFUEWeeGoJEdszlFRc=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-WAyBnp/ca2sD2A70gST0aSgEoXepkt9A2NLM0YHaHBc=",
      "url": "_framework/dotnet.native.w2rpj55hda.js"
    },
    {
      "hash": "sha256-tEwZZk1WBUqyH6ngYvCF3+XqQIvSuM0LGXiezBWv/uU=",
      "url": "_framework/dotnet.native.wvph2hfouj.wasm"
    },
    {
      "hash": "sha256-kTZbe5ESp04VMT22TnjRmFj88VbtEcohZfCm4og/IDw=",
      "url": "_framework/dotnet.runtime.5nhp1wfg9b.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-hCAel3LDqjEatW42wAwcNKCmEoQUIXunnv8Ix0nksQo=",
      "url": "_framework/netstandard.kw3bgublwz.wasm"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-z8OR40MowJ8GgK6P89Y+hiJK5+cclzFHzLhFQLL92bg=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-WSzjGPPkj65Q+4NZEdHqWKvZVfdfp9k8zXQsUIBPJ78=",
      "url": "css/extended.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-sR6haqHDKZF2/DyZa7mGQCVhSYNXgALxToNdUCmipbA=",
      "url": "index.html"
    },
    {
      "hash": "sha256-DZaFwVQD04A5i6qfWiT4LPqs8CZS6EEVhAW2LDKJbMI=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-Y00NreS8QvkVJ/0jwpIn0ojYkqkUMLCnGQhUoQE2dBc=",
      "url": "resources/AzerDil.json"
    },
    {
      "hash": "sha256-IVOgJnFhyiy+Sd0V3IaEoUnkS77ieRdQc9EeEbxXJGw=",
      "url": "resources/Biznes.json"
    },
    {
      "hash": "sha256-iueKNcbAUxiHVzavhxSQ1RYS5g3KkKvgN3KczfYcB5U=",
      "url": "resources/DifferentialEquations.json"
    },
    {
      "hash": "sha256-0ahGEJwC4E2cJQxwRuQ0AMI0pJarATFyM1pJnwyIvjY=",
      "url": "resources/FunOfIT.json"
    },
    {
      "hash": "sha256-oBwLpSvHxWFkE7TnLWCFSD7/g3y5IPT9bQ4zOGcV4qA=",
      "url": "resources/Ginekologiya.json"
    },
    {
      "hash": "sha256-ntv/VzbcruNmk7axvSOCNlpcB2af1Toq+zFwJssQqtE=",
      "url": "resources/History.json"
    },
    {
      "hash": "sha256-aPk/vr0K2ymRMybbjexal0NhPcuGq49kwoqYZBGWejc=",
      "url": "resources/Inform.json"
    },
    {
      "hash": "sha256-o9iYuMmOirKGHqTaLVlkYBkEPd/Oah0kkD7pwnE3YZA=",
      "url": "resources/LinearAlgebra.json"
    },
    {
      "hash": "sha256-h97YAwk+FFfqSsWtDkRzr+xz5ubK1tgRYmnMRXGGW8c=",
      "url": "resources/Math.json"
    },
    {
      "hash": "sha256-fpFhyS8Tj6byWYPE/pSOGebllY3ww+Sn2QEm7t9/wKg=",
      "url": "resources/Physics.json"
    },
    {
      "hash": "sha256-iAjTOssWhG7yC2d18HRkooNju8JlCBe5pO/PEXYkqC8=",
      "url": "resources/Programming.json"
    },
    {
      "hash": "sha256-Tp5NHcanwEG+3jWc7ahvrK0XqxjxCV5znLlv+Yg5P4U=",
      "url": "resources/Vusala.json"
    },
    {
      "hash": "sha256-paIeuWnSzjeLGITWkk4p3rcejUsZWCJGPeOK9UhWXtg=",
      "url": "weather.json"
    }
  ]
};
