self.assetsManifest = {
  "version": "VVib3kvu",
  "assets": [
    {
      "hash": "sha256-RZaJo+IYciR1DekP2t+tvrQ39NXbGGlOzWX2EIHSlic=",
      "url": "BlHell-per.styles.css"
    },
    {
      "hash": "sha256-1/RIvunzfxlZYY6hwGH4Xq/gQeqpS0uU23vPpMoPcME=",
      "url": "Pages/Constructor.razor.js"
    },
    {
      "hash": "sha256-qbO919CAYK4kRxWDRW3CehclkGcaxvcdMilLG4sKVe8=",
      "url": "_content/BlazorAnimation/animate.css"
    },
    {
      "hash": "sha256-+t/o5a1+4WbQxhoZypQHhvyATOlNrCBf5wRvVZ3/lrU=",
      "url": "_content/BlazorAnimation/blazorAnimationInterop.js"
    },
    {
      "hash": "sha256-PtApvXsjtN3h6TrGmJjCQsaFMN/pyLARBUCEQhLn7Oc=",
      "url": "_content/BlazorDownloadFile/BlazorDownloadFileScript.js"
    },
    {
      "hash": "sha256-Hh7BRmiYuRD1Lq8ZF9jVWOOJuN3tWPS5M2lLZzuayjw=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-weSY1+xC2IWsc4ncUHtQhWp3H5eek/LVHZEDlWdgryY=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-yZIAc6YlMT//OJu1H1/hNitHUUYjgXUpRMiNPOBnZfU=",
      "url": "_framework/BlHell-per.7swxdrhfty.wasm"
    },
    {
      "hash": "sha256-mtBFvvJ5Abqym6TJo3ybyKAvNw37CZOylAzGFPXBG2s=",
      "url": "_framework/BlazorAnimation.qfj0d0mxnh.wasm"
    },
    {
      "hash": "sha256-YB8HlaKSU6hGhkiMwSSlwRa4MDljnOAAmxBFTAqQWes=",
      "url": "_framework/BlazorDownloadFile.ct05c4bfyq.wasm"
    },
    {
      "hash": "sha256-iLxTio+CuXrAVvHl7FWdAuLaq5Imu8rSOJ6hzxQhRmk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.gqka07kwp7.wasm"
    },
    {
      "hash": "sha256-9LH5dSWW+Kx1mEdr0EPTInzIrgUi9bU/bTAm4vHsHv8=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.wd827pb4ol.wasm"
    },
    {
      "hash": "sha256-wkcm++Lk6tpwju7d/7A/Rjhj7l5V/LWWaQhx3DHgdh8=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.u9mc0juxx6.wasm"
    },
    {
      "hash": "sha256-tiM4ksgVFF78duzlwkKnhZqQbs9dx9kmG0kbD57fRNk=",
      "url": "_framework/Microsoft.AspNetCore.Components.uryxqdkbpe.wasm"
    },
    {
      "hash": "sha256-GjI9vkQKnVxmTLe8o7kZYAwFxKE0/UQnSKrzxuXGAsQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.u3l5g6tuv0.wasm"
    },
    {
      "hash": "sha256-FQjLsQaz4KTpgQKQkcTn5A5IuUgcYT6MpYuBsN/vjX0=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.7d9a22amlg.wasm"
    },
    {
      "hash": "sha256-kizMyczNs6pFkLVfw3WQsZxAo/8HgmtiDuHyKMQLmpA=",
      "url": "_framework/Microsoft.Extensions.Configuration.iclqaprdn6.wasm"
    },
    {
      "hash": "sha256-owCCYCSm5dyA3piKVO4uRr0yp6VtROzVXwWydj61Ma8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.lig3huuvfb.wasm"
    },
    {
      "hash": "sha256-MOVlPkeO9+8Nu3CBHZqiF9YgpspbjBuCIS4K9LqliPs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.clr2lmubvg.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-DFmtrnKYzzerBuR5f43sd/+DpUnvSV+FBOLJQEBLWK8=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.0prz4zc256.wasm"
    },
    {
      "hash": "sha256-0PwVT3DJI3W4JqGJbzbuXm7Z6pEsGxwIJp8zWaidzJw=",
      "url": "_framework/Microsoft.Extensions.Logging.g06jewh4ge.wasm"
    },
    {
      "hash": "sha256-Jnlcdnj7e3zcgyrLOFR0nT5K62FsZ8V6jdO13jLjsSM=",
      "url": "_framework/Microsoft.Extensions.Options.iiwxc6oefm.wasm"
    },
    {
      "hash": "sha256-94QoZadgwzeiFIU+yLaR2X8Nu3IA4MJHyHNo3rfcep8=",
      "url": "_framework/Microsoft.Extensions.Primitives.xuv72fcd9m.wasm"
    },
    {
      "hash": "sha256-WuuQXW1+AnPHafZKt7ukqmwRDrGYbEV2LhxNuPl+ybo=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.y1ydbrr1bj.wasm"
    },
    {
      "hash": "sha256-nvGGypprybtKTICn6+vbklsAYvogZU55KKo7Zd4Trto=",
      "url": "_framework/Microsoft.JSInterop.ijy7jdc5cu.wasm"
    },
    {
      "hash": "sha256-k8DreeatigNmRUWV2vK5IJZnKrYt2H5v8D94nhi8Ups=",
      "url": "_framework/MudBlazor.fll9v3wisj.wasm"
    },
    {
      "hash": "sha256-cwZXhiUBkPh+3hMBFm4dIgRwB5V0baGNSA/CPvcfD94=",
      "url": "_framework/System.Collections.Concurrent.v526y1vfow.wasm"
    },
    {
      "hash": "sha256-mLUzozToqp2JYRHco7RxMLla4ajjZf2dSFZQdP0MQ80=",
      "url": "_framework/System.Collections.Immutable.kph3y7jjzy.wasm"
    },
    {
      "hash": "sha256-jghclVhUYQHD/mDiZ1EZFHXP+ID76HT/gtlgfEtQ5pk=",
      "url": "_framework/System.Collections.NonGeneric.ud8k4b8ihk.wasm"
    },
    {
      "hash": "sha256-812KOXsdj0TFPXQXh1o5SPtEEHqYoPlelw2eG4O0Kfg=",
      "url": "_framework/System.Collections.Specialized.5qilg863is.wasm"
    },
    {
      "hash": "sha256-jAVjuNL5Y9oYoWcjvjCqZ9raFpYffdsP/tHvzYAEk8w=",
      "url": "_framework/System.Collections.gncu65zxhi.wasm"
    },
    {
      "hash": "sha256-M+QkekpO2jscOB42OaaDHkngPRN8dwMiGfeMv8YtGbg=",
      "url": "_framework/System.ComponentModel.389mgrr0ti.wasm"
    },
    {
      "hash": "sha256-V4xCXKLph98HyUUeODhFfSCGGFvncdOcVaqn74YUaEI=",
      "url": "_framework/System.ComponentModel.Annotations.brcj15zf57.wasm"
    },
    {
      "hash": "sha256-FFKFhpvRrS1Ri241t2cnhO4euze6u0LIxob2jZgxplY=",
      "url": "_framework/System.ComponentModel.Primitives.o35d74wwwt.wasm"
    },
    {
      "hash": "sha256-W+evTCMzkeI6LlG92uQzgdAtQ9ou1NCeb9uI07lh0dE=",
      "url": "_framework/System.ComponentModel.TypeConverter.bwtgco4fvw.wasm"
    },
    {
      "hash": "sha256-7EE36cErAb5ikAXirFwTxnLn4Xc+RrLnv92BJrz3EYc=",
      "url": "_framework/System.Console.g7ifszzwjw.wasm"
    },
    {
      "hash": "sha256-MC//oZihkrDor+F69HNYr68bhQyAKbvs+DuBShADNsA=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.0cigcllfwc.wasm"
    },
    {
      "hash": "sha256-0uljQYkN7r22Bww1ENZAVGTupoPwfKICKYE7IbIfkLU=",
      "url": "_framework/System.IO.Pipelines.ij3x2x6ncl.wasm"
    },
    {
      "hash": "sha256-AYKBEcDznREYaFuWEiXKmCV++llWZqJ1rbJJ5Gg+2SU=",
      "url": "_framework/System.Linq.1cxp56t53k.wasm"
    },
    {
      "hash": "sha256-FvQdn6EhegstnSWJSUcklwd0+8dTFZ/aNuJNZObzIjI=",
      "url": "_framework/System.Linq.Expressions.ypjdvwd2dq.wasm"
    },
    {
      "hash": "sha256-kc8nGU1sKOWWJmmJo0olk9oz/1UVdzGJ3Qtb3bhBuTU=",
      "url": "_framework/System.Memory.726r5hplox.wasm"
    },
    {
      "hash": "sha256-VgyArlm0dDzM2GSzeDVtvRxDuX/tMCDnSW+4ltd7Dvk=",
      "url": "_framework/System.Net.Http.e7uflmy9kr.wasm"
    },
    {
      "hash": "sha256-lpuToxoC6gyjBIE2Z0NrXP7Q+Zku/Hml1ND72k+jG48=",
      "url": "_framework/System.Net.Primitives.qk8k4u090q.wasm"
    },
    {
      "hash": "sha256-/rXUzqlHPqEhnzNyisIb9kesOINuRJooQRfQ77EBIuI=",
      "url": "_framework/System.ObjectModel.qtptmqpubq.wasm"
    },
    {
      "hash": "sha256-6D/OXGd0SoHyY8VZAH5g5G+RSZMvLRedg3JrEOIpe7U=",
      "url": "_framework/System.Private.CoreLib.snss4fexib.wasm"
    },
    {
      "hash": "sha256-ReTOR0VUGYOqDzQ5+bagYHzWl4cm87qbN50q6zAHOZ0=",
      "url": "_framework/System.Private.Uri.7194l4dypq.wasm"
    },
    {
      "hash": "sha256-3IoLyXDPZlSSNuf0cCFYH/6pnHsiIz+bg/ptKuGnMiI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.4wymnd9fjf.wasm"
    },
    {
      "hash": "sha256-ilopIfz9cTL0O6KEEioZ5FAXxCRp5QiGP4z5igxUGG8=",
      "url": "_framework/System.Runtime.Serialization.Primitives.qznoixqk0h.wasm"
    },
    {
      "hash": "sha256-+kWusLJuEKA2gW37dkqjANIvJWI9VYYcoeS7utnqae8=",
      "url": "_framework/System.Runtime.qo80qoqrco.wasm"
    },
    {
      "hash": "sha256-Pwzawg4zJdC5lIyz1AM3dUYbNt/j7hE+Qo+qC3X39yg=",
      "url": "_framework/System.Text.Encodings.Web.l3kos337af.wasm"
    },
    {
      "hash": "sha256-k4xKHLiiCeDjs3zjccsbhESaproMywIH74hOvEEoT0k=",
      "url": "_framework/System.Text.Json.9t58saakcu.wasm"
    },
    {
      "hash": "sha256-yhn0udwRxy6q91BW0qN6Jyw1NyXCYIOsKg82XBEPncw=",
      "url": "_framework/System.Text.RegularExpressions.m49chj9bdl.wasm"
    },
    {
      "hash": "sha256-9XFBcPudw1WgBQrTtYhbHqJBIqNp24ghbbCQiMHI9kk=",
      "url": "_framework/System.Threading.Tasks.Extensions.jucghyvye4.wasm"
    },
    {
      "hash": "sha256-fZ9o2IQTIELEttSIeZ1yev0uL+0qIYnwOC1p/5RM/0k=",
      "url": "_framework/System.Threading.zcb42vnja5.wasm"
    },
    {
      "hash": "sha256-DM5iEENhrifGKn33Y7cqRzxC0OtHXYOKO13icwIazj8=",
      "url": "_framework/System.cunp5qiwjj.wasm"
    },
    {
      "hash": "sha256-uTQnI2/es9XMy0omcaaQMywltHSTZVcjzSx96PgW5TY=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-VSrDABliXym1uaVGf/4XAZdHT7sA5xiMiD/TmJeALDc=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-pf2P11GPrPDRMygks46BPb4T9E0RA0y6N7Sb3NBSRvg=",
      "url": "_framework/dotnet.native.ffj4va6u6z.js"
    },
    {
      "hash": "sha256-UoOdsgoDxkf9L/Hv9bKhJH30ERjy4eglN+ZaRNa5Lho=",
      "url": "_framework/dotnet.native.y3q2scca8m.wasm"
    },
    {
      "hash": "sha256-gbZjXNFbH7V8lcix+H0TUDJHLeFUA3n3IMu7fLh4D80=",
      "url": "_framework/dotnet.runtime.d1pzlaz2ez.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-L8akktR7QFCPD0LM6WzbS0PwtkHFKIv65KpXl1PqiiI=",
      "url": "_framework/netstandard.ln4hs38ovd.wasm"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-z8OR40MowJ8GgK6P89Y+hiJK5+cclzFHzLhFQLL92bg=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-myltxrknUVoInGTPoh3wTCqm8kbZJ1QpqcQC76q1Q2Y=",
      "url": "css/extended.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-1nikP68Sg3p12uBF6ipEGRYXPSDiqRJRlW3SjwW0IJk=",
      "url": "index.html"
    },
    {
      "hash": "sha256-qKLhaKA/JCRANQ7DHbR4q0FQFjahBNxJGTytPr8+tTc=",
      "url": "js/BrotliModule.js"
    },
    {
      "hash": "sha256-n8JqbVqXP608pyu0PQ0M7znaAsA1Tqheho64a6C0jMI=",
      "url": "js/KaTeX.cs.js"
    },
    {
      "hash": "sha256-zG/WsT2Hoo/vrfSbaf/rSEIAIzIp8AKcemlaX45B2u4=",
      "url": "js/PWAService.cs.js"
    },
    {
      "hash": "sha256-sMlf1RhvrHWE5u5ol+FEw4t6ETbSo6w6HsKdaTA5lPE=",
      "url": "js/Uni.js"
    },
    {
      "hash": "sha256-DZaFwVQD04A5i6qfWiT4LPqs8CZS6EEVhAW2LDKJbMI=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-Y00NreS8QvkVJ/0jwpIn0ojYkqkUMLCnGQhUoQE2dBc=",
      "url": "resources/AzerDil.json"
    },
    {
      "hash": "sha256-IVOgJnFhyiy+Sd0V3IaEoUnkS77ieRdQc9EeEbxXJGw=",
      "url": "resources/Biznes.json"
    },
    {
      "hash": "sha256-4+wvfMHaRL14IzWsC11sNwJOzKRY09+oY5KTqlkiI10=",
      "url": "resources/DifferentialEquations.json"
    },
    {
      "hash": "sha256-X4c/jlHJ4jZL7gzP3KjaSSYKLIdvyDxw1CX/qEB1bPA=",
      "url": "resources/Eng.json"
    },
    {
      "hash": "sha256-vYkTBuxjNAEER8ANX26ikiY9v4BjTch4g4qD6izyaZE=",
      "url": "resources/FunOfIT.json"
    },
    {
      "hash": "sha256-oBwLpSvHxWFkE7TnLWCFSD7/g3y5IPT9bQ4zOGcV4qA=",
      "url": "resources/Ginekologiya.json"
    },
    {
      "hash": "sha256-ntv/VzbcruNmk7axvSOCNlpcB2af1Toq+zFwJssQqtE=",
      "url": "resources/History.json"
    },
    {
      "hash": "sha256-aPk/vr0K2ymRMybbjexal0NhPcuGq49kwoqYZBGWejc=",
      "url": "resources/Inform.json"
    },
    {
      "hash": "sha256-oWdoHriH0up4eD63WrQSjSgAM4yJ2FQLSQDFJY++PO8=",
      "url": "resources/LinearAlgebra.json"
    },
    {
      "hash": "sha256-h97YAwk+FFfqSsWtDkRzr+xz5ubK1tgRYmnMRXGGW8c=",
      "url": "resources/Math.json"
    },
    {
      "hash": "sha256-mMzjMmXxwFaJ4hTUiMcvTP5fcg8S36b0RyZ+f7vyVMI=",
      "url": "resources/Physics.json"
    },
    {
      "hash": "sha256-QxYaEm+6UI8l6rj99AJ3i7/7rOaQ1VQs3CH4NuSwr6s=",
      "url": "resources/Programming.json"
    },
    {
      "hash": "sha256-GMayAI8sgZ8QdNCvqR5pLd71pQStfbFvTlMQdl7Tgnw=",
      "url": "resources/Vusala.json"
    }
  ]
};
