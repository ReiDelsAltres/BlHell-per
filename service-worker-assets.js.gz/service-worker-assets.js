self.assetsManifest = {
  "version": "daVsCDh1",
  "assets": [
    {
      "hash": "sha256-RZaJo+IYciR1DekP2t+tvrQ39NXbGGlOzWX2EIHSlic=",
      "url": "BlHell-per.styles.css"
    },
    {
      "hash": "sha256-1/RIvunzfxlZYY6hwGH4Xq/gQeqpS0uU23vPpMoPcME=",
      "url": "Pages/Constructor.razor.js"
    },
    {
      "hash": "sha256-qbO919CAYK4kRxWDRW3CehclkGcaxvcdMilLG4sKVe8=",
      "url": "_content/BlazorAnimation/animate.css"
    },
    {
      "hash": "sha256-+t/o5a1+4WbQxhoZypQHhvyATOlNrCBf5wRvVZ3/lrU=",
      "url": "_content/BlazorAnimation/blazorAnimationInterop.js"
    },
    {
      "hash": "sha256-PtApvXsjtN3h6TrGmJjCQsaFMN/pyLARBUCEQhLn7Oc=",
      "url": "_content/BlazorDownloadFile/BlazorDownloadFileScript.js"
    },
    {
      "hash": "sha256-Hh7BRmiYuRD1Lq8ZF9jVWOOJuN3tWPS5M2lLZzuayjw=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-weSY1+xC2IWsc4ncUHtQhWp3H5eek/LVHZEDlWdgryY=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-LCxfIFOcfzl0Ab5CBw5AaGksCBa6xS5EOvt3UO1Pdcg=",
      "url": "_framework/BlHell-per.gf8msbzyxe.wasm"
    },
    {
      "hash": "sha256-mtBFvvJ5Abqym6TJo3ybyKAvNw37CZOylAzGFPXBG2s=",
      "url": "_framework/BlazorAnimation.qfj0d0mxnh.wasm"
    },
    {
      "hash": "sha256-YB8HlaKSU6hGhkiMwSSlwRa4MDljnOAAmxBFTAqQWes=",
      "url": "_framework/BlazorDownloadFile.ct05c4bfyq.wasm"
    },
    {
      "hash": "sha256-iLxTio+CuXrAVvHl7FWdAuLaq5Imu8rSOJ6hzxQhRmk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.gqka07kwp7.wasm"
    },
    {
      "hash": "sha256-9LH5dSWW+Kx1mEdr0EPTInzIrgUi9bU/bTAm4vHsHv8=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.wd827pb4ol.wasm"
    },
    {
      "hash": "sha256-wkcm++Lk6tpwju7d/7A/Rjhj7l5V/LWWaQhx3DHgdh8=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.u9mc0juxx6.wasm"
    },
    {
      "hash": "sha256-tiM4ksgVFF78duzlwkKnhZqQbs9dx9kmG0kbD57fRNk=",
      "url": "_framework/Microsoft.AspNetCore.Components.uryxqdkbpe.wasm"
    },
    {
      "hash": "sha256-GjI9vkQKnVxmTLe8o7kZYAwFxKE0/UQnSKrzxuXGAsQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.u3l5g6tuv0.wasm"
    },
    {
      "hash": "sha256-FQjLsQaz4KTpgQKQkcTn5A5IuUgcYT6MpYuBsN/vjX0=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.7d9a22amlg.wasm"
    },
    {
      "hash": "sha256-kizMyczNs6pFkLVfw3WQsZxAo/8HgmtiDuHyKMQLmpA=",
      "url": "_framework/Microsoft.Extensions.Configuration.iclqaprdn6.wasm"
    },
    {
      "hash": "sha256-owCCYCSm5dyA3piKVO4uRr0yp6VtROzVXwWydj61Ma8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.lig3huuvfb.wasm"
    },
    {
      "hash": "sha256-MOVlPkeO9+8Nu3CBHZqiF9YgpspbjBuCIS4K9LqliPs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.clr2lmubvg.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-DFmtrnKYzzerBuR5f43sd/+DpUnvSV+FBOLJQEBLWK8=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.0prz4zc256.wasm"
    },
    {
      "hash": "sha256-0PwVT3DJI3W4JqGJbzbuXm7Z6pEsGxwIJp8zWaidzJw=",
      "url": "_framework/Microsoft.Extensions.Logging.g06jewh4ge.wasm"
    },
    {
      "hash": "sha256-Jnlcdnj7e3zcgyrLOFR0nT5K62FsZ8V6jdO13jLjsSM=",
      "url": "_framework/Microsoft.Extensions.Options.iiwxc6oefm.wasm"
    },
    {
      "hash": "sha256-94QoZadgwzeiFIU+yLaR2X8Nu3IA4MJHyHNo3rfcep8=",
      "url": "_framework/Microsoft.Extensions.Primitives.xuv72fcd9m.wasm"
    },
    {
      "hash": "sha256-WuuQXW1+AnPHafZKt7ukqmwRDrGYbEV2LhxNuPl+ybo=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.y1ydbrr1bj.wasm"
    },
    {
      "hash": "sha256-nvGGypprybtKTICn6+vbklsAYvogZU55KKo7Zd4Trto=",
      "url": "_framework/Microsoft.JSInterop.ijy7jdc5cu.wasm"
    },
    {
      "hash": "sha256-k8DreeatigNmRUWV2vK5IJZnKrYt2H5v8D94nhi8Ups=",
      "url": "_framework/MudBlazor.fll9v3wisj.wasm"
    },
    {
      "hash": "sha256-cwZXhiUBkPh+3hMBFm4dIgRwB5V0baGNSA/CPvcfD94=",
      "url": "_framework/System.Collections.Concurrent.v526y1vfow.wasm"
    },
    {
      "hash": "sha256-mLUzozToqp2JYRHco7RxMLla4ajjZf2dSFZQdP0MQ80=",
      "url": "_framework/System.Collections.Immutable.kph3y7jjzy.wasm"
    },
    {
      "hash": "sha256-jghclVhUYQHD/mDiZ1EZFHXP+ID76HT/gtlgfEtQ5pk=",
      "url": "_framework/System.Collections.NonGeneric.ud8k4b8ihk.wasm"
    },
    {
      "hash": "sha256-812KOXsdj0TFPXQXh1o5SPtEEHqYoPlelw2eG4O0Kfg=",
      "url": "_framework/System.Collections.Specialized.5qilg863is.wasm"
    },
    {
      "hash": "sha256-jAVjuNL5Y9oYoWcjvjCqZ9raFpYffdsP/tHvzYAEk8w=",
      "url": "_framework/System.Collections.gncu65zxhi.wasm"
    },
    {
      "hash": "sha256-M+QkekpO2jscOB42OaaDHkngPRN8dwMiGfeMv8YtGbg=",
      "url": "_framework/System.ComponentModel.389mgrr0ti.wasm"
    },
    {
      "hash": "sha256-V4xCXKLph98HyUUeODhFfSCGGFvncdOcVaqn74YUaEI=",
      "url": "_framework/System.ComponentModel.Annotations.brcj15zf57.wasm"
    },
    {
      "hash": "sha256-FFKFhpvRrS1Ri241t2cnhO4euze6u0LIxob2jZgxplY=",
      "url": "_framework/System.ComponentModel.Primitives.o35d74wwwt.wasm"
    },
    {
      "hash": "sha256-W+evTCMzkeI6LlG92uQzgdAtQ9ou1NCeb9uI07lh0dE=",
      "url": "_framework/System.ComponentModel.TypeConverter.bwtgco4fvw.wasm"
    },
    {
      "hash": "sha256-7EE36cErAb5ikAXirFwTxnLn4Xc+RrLnv92BJrz3EYc=",
      "url": "_framework/System.Console.g7ifszzwjw.wasm"
    },
    {
      "hash": "sha256-MC//oZihkrDor+F69HNYr68bhQyAKbvs+DuBShADNsA=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.0cigcllfwc.wasm"
    },
    {
      "hash": "sha256-0uljQYkN7r22Bww1ENZAVGTupoPwfKICKYE7IbIfkLU=",
      "url": "_framework/System.IO.Pipelines.ij3x2x6ncl.wasm"
    },
    {
      "hash": "sha256-AYKBEcDznREYaFuWEiXKmCV++llWZqJ1rbJJ5Gg+2SU=",
      "url": "_framework/System.Linq.1cxp56t53k.wasm"
    },
    {
      "hash": "sha256-FvQdn6EhegstnSWJSUcklwd0+8dTFZ/aNuJNZObzIjI=",
      "url": "_framework/System.Linq.Expressions.ypjdvwd2dq.wasm"
    },
    {
      "hash": "sha256-kc8nGU1sKOWWJmmJo0olk9oz/1UVdzGJ3Qtb3bhBuTU=",
      "url": "_framework/System.Memory.726r5hplox.wasm"
    },
    {
      "hash": "sha256-VgyArlm0dDzM2GSzeDVtvRxDuX/tMCDnSW+4ltd7Dvk=",
      "url": "_framework/System.Net.Http.e7uflmy9kr.wasm"
    },
    {
      "hash": "sha256-lpuToxoC6gyjBIE2Z0NrXP7Q+Zku/Hml1ND72k+jG48=",
      "url": "_framework/System.Net.Primitives.qk8k4u090q.wasm"
    },
    {
      "hash": "sha256-/rXUzqlHPqEhnzNyisIb9kesOINuRJooQRfQ77EBIuI=",
      "url": "_framework/System.ObjectModel.qtptmqpubq.wasm"
    },
    {
      "hash": "sha256-Lvf7DQcIb8+ZAHJfKaftUuTgJjxLBw+qcA29fIrOuas=",
      "url": "_framework/System.Private.CoreLib.q2rbzimv2x.wasm"
    },
    {
      "hash": "sha256-ReTOR0VUGYOqDzQ5+bagYHzWl4cm87qbN50q6zAHOZ0=",
      "url": "_framework/System.Private.Uri.7194l4dypq.wasm"
    },
    {
      "hash": "sha256-Let6198wTMt9c7FcUgjcailX7RZmzvYtmKmAaCVTvu8=",
      "url": "_framework/System.Runtime.5mx4sv7iue.wasm"
    },
    {
      "hash": "sha256-3IoLyXDPZlSSNuf0cCFYH/6pnHsiIz+bg/ptKuGnMiI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.4wymnd9fjf.wasm"
    },
    {
      "hash": "sha256-ilopIfz9cTL0O6KEEioZ5FAXxCRp5QiGP4z5igxUGG8=",
      "url": "_framework/System.Runtime.Serialization.Primitives.qznoixqk0h.wasm"
    },
    {
      "hash": "sha256-Pwzawg4zJdC5lIyz1AM3dUYbNt/j7hE+Qo+qC3X39yg=",
      "url": "_framework/System.Text.Encodings.Web.l3kos337af.wasm"
    },
    {
      "hash": "sha256-k4xKHLiiCeDjs3zjccsbhESaproMywIH74hOvEEoT0k=",
      "url": "_framework/System.Text.Json.9t58saakcu.wasm"
    },
    {
      "hash": "sha256-yhn0udwRxy6q91BW0qN6Jyw1NyXCYIOsKg82XBEPncw=",
      "url": "_framework/System.Text.RegularExpressions.m49chj9bdl.wasm"
    },
    {
      "hash": "sha256-9XFBcPudw1WgBQrTtYhbHqJBIqNp24ghbbCQiMHI9kk=",
      "url": "_framework/System.Threading.Tasks.Extensions.jucghyvye4.wasm"
    },
    {
      "hash": "sha256-fZ9o2IQTIELEttSIeZ1yev0uL+0qIYnwOC1p/5RM/0k=",
      "url": "_framework/System.Threading.zcb42vnja5.wasm"
    },
    {
      "hash": "sha256-DM5iEENhrifGKn33Y7cqRzxC0OtHXYOKO13icwIazj8=",
      "url": "_framework/System.cunp5qiwjj.wasm"
    },
    {
      "hash": "sha256-SanBegBmQ591CQZxKB7T8VKTeRtt+KWTlw8umIGF4HU=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-VSrDABliXym1uaVGf/4XAZdHT7sA5xiMiD/TmJeALDc=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-pf2P11GPrPDRMygks46BPb4T9E0RA0y6N7Sb3NBSRvg=",
      "url": "_framework/dotnet.native.ffj4va6u6z.js"
    },
    {
      "hash": "sha256-mNkZLn1RCZnWIDC71/+jORdbpg+hvNoQayJ7YQIAE2M=",
      "url": "_framework/dotnet.native.ktwp44yun8.wasm"
    },
    {
      "hash": "sha256-gbZjXNFbH7V8lcix+H0TUDJHLeFUA3n3IMu7fLh4D80=",
      "url": "_framework/dotnet.runtime.d1pzlaz2ez.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-L8akktR7QFCPD0LM6WzbS0PwtkHFKIv65KpXl1PqiiI=",
      "url": "_framework/netstandard.ln4hs38ovd.wasm"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-z8OR40MowJ8GgK6P89Y+hiJK5+cclzFHzLhFQLL92bg=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-myltxrknUVoInGTPoh3wTCqm8kbZJ1QpqcQC76q1Q2Y=",
      "url": "css/extended.css"
    },
    {
      "hash": "sha256-shr67lprMYE9JXbZRfA5X6l1wKpppGpMUQhzt5/oHPs=",
      "url": "css/imported/Katex/Katex.css"
    },
    {
      "hash": "sha256-aFNIQLz90r/7bw6N60hoTdAefwTqKBMmdXevuQbeHRM=",
      "url": "css/imported/Katex/fonts/KaTeX_AMS-Regular.ttf"
    },
    {
      "hash": "sha256-MNqR6EyJP4deJSaJ+uvcWQsocRReitx/mp1NvYzgslE=",
      "url": "css/imported/Katex/fonts/KaTeX_AMS-Regular.woff"
    },
    {
      "hash": "sha256-DN04fJWQoan5eUVgAi27WWVKfYbxh6oMgUla1C06cwg=",
      "url": "css/imported/Katex/fonts/KaTeX_AMS-Regular.woff2"
    },
    {
      "hash": "sha256-B9jjA85PwStLtU8QBBcN0ZCh89tF1AD+aAYN8+CJcmg=",
      "url": "css/imported/Katex/fonts/KaTeX_Caligraphic-Bold.ttf"
    },
    {
      "hash": "sha256-Gua9dHVZDpfn8UWongnM3jIvemvAuRYHsci47igpD+0=",
      "url": "css/imported/Katex/fonts/KaTeX_Caligraphic-Bold.woff"
    },
    {
      "hash": "sha256-3ncB5Czx9M8LdmwD+yeXcgfu4vT9XXb6ghiEBtpD6kw=",
      "url": "css/imported/Katex/fonts/KaTeX_Caligraphic-Bold.woff2"
    },
    {
      "hash": "sha256-7Qt0Ny/u/LucBmay4hDaN7fkn6f7vz7rEdtfaT2s+7c=",
      "url": "css/imported/Katex/fonts/KaTeX_Caligraphic-Regular.ttf"
    },
    {
      "hash": "sha256-M5jdAjAlV6eT8oY/iOAtls4Q3yq/+gfI6fqQd1EW5lw=",
      "url": "css/imported/Katex/fonts/KaTeX_Caligraphic-Regular.woff"
    },
    {
      "hash": "sha256-XVPnCtYHwjUhYt7J4JI/tU7Nr6zL9gTNjc99APrLmJs=",
      "url": "css/imported/Katex/fonts/KaTeX_Caligraphic-Regular.woff2"
    },
    {
      "hash": "sha256-kWPfnHEiQy5klbQin6kHHPmuhqdYrl78SSTsLhptvOE=",
      "url": "css/imported/Katex/fonts/KaTeX_Fraktur-Bold.ttf"
    },
    {
      "hash": "sha256-m+fOuIAEq4rRJAgiRvv8ykCR42OF1Oxu0d9nN12tUPs=",
      "url": "css/imported/Katex/fonts/KaTeX_Fraktur-Bold.woff"
    },
    {
      "hash": "sha256-dERO/Vk8AF4/RXO0RSRwTArwqTf+kRzKnpQGjQ0UDT8=",
      "url": "css/imported/Katex/fonts/KaTeX_Fraktur-Bold.woff2"
    },
    {
      "hash": "sha256-Hm+VeekOLKw3+PYKWXxDbgdcEUOFZSt8vrDewEISkbM=",
      "url": "css/imported/Katex/fonts/KaTeX_Fraktur-Regular.ttf"
    },
    {
      "hash": "sha256-Xih1O+cX2sl/VZ9JvBC+nPPBJN3KvaZlnRHLaP68ZGM=",
      "url": "css/imported/Katex/fonts/KaTeX_Fraktur-Regular.woff"
    },
    {
      "hash": "sha256-UYFNJw0G/wJV26B5mZT6TYyE0R8JlR1HWV9Kux82Atw=",
      "url": "css/imported/Katex/fonts/KaTeX_Fraktur-Regular.woff2"
    },
    {
      "hash": "sha256-E4rCjRZjswN+nF9SNx+lxj2DJPSjjSLNVz5uo6P9DPg=",
      "url": "css/imported/Katex/fonts/KaTeX_Main-Bold.ttf"
    },
    {
      "hash": "sha256-x2xdaWKX1RucsWOcfaQzTw597IG0KxEhO14l72cbuCI=",
      "url": "css/imported/Katex/fonts/KaTeX_Main-Bold.woff"
    },
    {
      "hash": "sha256-D2DRuJeTjskYyM4HMJJBG6+UOPZzlGVpP/GLD50gsCE=",
      "url": "css/imported/Katex/fonts/KaTeX_Main-Bold.woff2"
    },
    {
      "hash": "sha256-cO4fZKIPIEjCGUDvRtAUT9IVuqlTymmv0eMemFRPcI8=",
      "url": "css/imported/Katex/fonts/KaTeX_Main-BoldItalic.ttf"
    },
    {
      "hash": "sha256-pvfsDYRqx62XWtuJWcN+1JuUrLxK5DbbnOniAofkpkw=",
      "url": "css/imported/Katex/fonts/KaTeX_Main-BoldItalic.woff"
    },
    {
      "hash": "sha256-mc1Co8By2Rjy9EmEqAfPeqFuE1Rf0IdfwHxsZfmecVs=",
      "url": "css/imported/Katex/fonts/KaTeX_Main-BoldItalic.woff2"
    },
    {
      "hash": "sha256-DYWufMMPI3kKfxpYxKES/cqKrnaba6EUKa8dmLG2yzo=",
      "url": "css/imported/Katex/fonts/KaTeX_Main-Italic.ttf"
    },
    {
      "hash": "sha256-8dbvhvOxGlKL1RhRmb0kQ+yysN6tltiGdLWiwSviS98=",
      "url": "css/imported/Katex/fonts/KaTeX_Main-Italic.woff"
    },
    {
      "hash": "sha256-l0ecpszpBqvJYeyslvql+couYbjnZw1HWCa83umnwmc=",
      "url": "css/imported/Katex/fonts/KaTeX_Main-Italic.woff2"
    },
    {
      "hash": "sha256-0DMvUoaDcP2Drn+kZHD5DI8uqy/PErxPiAgLNAyVqDA=",
      "url": "css/imported/Katex/fonts/KaTeX_Main-Regular.ttf"
    },
    {
      "hash": "sha256-xjaNh+iho6XTN2I9g9jcS4aPJCqa1HYjfW+NHg8WjNw=",
      "url": "css/imported/Katex/fonts/KaTeX_Main-Regular.woff"
    },
    {
      "hash": "sha256-wjQs2Lhp4BdSqTIdwXIT/EDU0Ex5aIwdQ/LPMWq9eGY=",
      "url": "css/imported/Katex/fonts/KaTeX_Main-Regular.woff2"
    },
    {
      "hash": "sha256-+Td6sCcc2lmvJLz/vUak0MijVy/6/bs43irV6nsNXuU=",
      "url": "css/imported/Katex/fonts/KaTeX_Math-BoldItalic.ttf"
    },
    {
      "hash": "sha256-hQwK9cIjhJf+uvXkYdiAv0WMNB9C9PMw8bGrVpixmY4=",
      "url": "css/imported/Katex/fonts/KaTeX_Math-BoldItalic.woff"
    },
    {
      "hash": "sha256-3Ec0TbtstbZVyEYNVh9N9fUBuQyAStPGzsZf4yI1GrE=",
      "url": "css/imported/Katex/fonts/KaTeX_Math-BoldItalic.woff2"
    },
    {
      "hash": "sha256-CM6Y5RsE1YlFowHmOeAraZivKf39Yae4r90Hu/xHnUo=",
      "url": "css/imported/Katex/fonts/KaTeX_Math-Italic.ttf"
    },
    {
      "hash": "sha256-io0kRYE3GRK48/WiPiQ3yypZzZvK67A0bnIsBXN6JXE=",
      "url": "css/imported/Katex/fonts/KaTeX_Math-Italic.woff"
    },
    {
      "hash": "sha256-evWMXsjxMqLd3pAnxteBTezOTTuCKhEZKkKiDi6XMmQ=",
      "url": "css/imported/Katex/fonts/KaTeX_Math-Italic.woff2"
    },
    {
      "hash": "sha256-Hs4D95+VJ31X3H9rQ1p04TebDUYQSoUwKGtg/0k2nqA=",
      "url": "css/imported/Katex/fonts/KaTeX_SansSerif-Bold.ttf"
    },
    {
      "hash": "sha256-7OA8/YPiLCEs3vZv64RC0loIO+uYjbPxiD8/lzjXULo=",
      "url": "css/imported/Katex/fonts/KaTeX_SansSerif-Bold.woff"
    },
    {
      "hash": "sha256-6ZrlEUS/EjLvzBv+Wt02JixoZrD6qyT6dXQOG5hXemI=",
      "url": "css/imported/Katex/fonts/KaTeX_SansSerif-Bold.woff2"
    },
    {
      "hash": "sha256-OTHdgfrthroCG7K73Db1vtmjjWtPQHespZsmWqGwIIM=",
      "url": "css/imported/Katex/fonts/KaTeX_SansSerif-Italic.ttf"
    },
    {
      "hash": "sha256-ke5nUAzAEpqgrOOsXGH/FpIQLw8x0CtpNH+6Ndy3W/I=",
      "url": "css/imported/Katex/fonts/KaTeX_SansSerif-Italic.woff"
    },
    {
      "hash": "sha256-ALJqyCXiCVBWOW4FU7isJtP4rRWMOCbii0xFs4XEcUo=",
      "url": "css/imported/Katex/fonts/KaTeX_SansSerif-Italic.woff2"
    },
    {
      "hash": "sha256-826ol+GfSi5XHR6QDk43EOQ43rBahCSGBFugo+YWpK0=",
      "url": "css/imported/Katex/fonts/KaTeX_SansSerif-Regular.ttf"
    },
    {
      "hash": "sha256-EeTcimRx/21u5WHVPRD96PdInnmCV/9EnF03wZdDVgU=",
      "url": "css/imported/Katex/fonts/KaTeX_SansSerif-Regular.woff"
    },
    {
      "hash": "sha256-aOjHPvQq/TzOxYvw+6MCzORIk45/wCCl4x+KlS7uE0I=",
      "url": "css/imported/Katex/fonts/KaTeX_SansSerif-Regular.woff2"
    },
    {
      "hash": "sha256-HGfwaP6ouwm/CZwIixz2S9J1Fqbgf0aENEhzVku2amc=",
      "url": "css/imported/Katex/fonts/KaTeX_Script-Regular.ttf"
    },
    {
      "hash": "sha256-2WzfKzvdTWSo/V90pMRn8SOopzkxzUNYifCP+vm/lHo=",
      "url": "css/imported/Katex/fonts/KaTeX_Script-Regular.woff"
    },
    {
      "hash": "sha256-A21OlRSbaf+bzAzVV3Hv6yX/o5Ryk+aazXjVrDKMaEs=",
      "url": "css/imported/Katex/fonts/KaTeX_Script-Regular.woff2"
    },
    {
      "hash": "sha256-lbbS8aUBc7/tuMY+HRyZsQQn0KTfQgHLRFE7ImlRois=",
      "url": "css/imported/Katex/fonts/KaTeX_Size1-Regular.ttf"
    },
    {
      "hash": "sha256-yUPMmGOE9Z6GvqX9fcUKnE3+Vnp8BetA1nkHIN6tl8k=",
      "url": "css/imported/Katex/fonts/KaTeX_Size1-Regular.woff"
    },
    {
      "hash": "sha256-a0fEAWa22+IaXfyncYQT8hR/0jmb4bpgXYrTnO3yXf4=",
      "url": "css/imported/Katex/fonts/KaTeX_Size1-Regular.woff2"
    },
    {
      "hash": "sha256-prIJn7VVxg46DbOgiELr8dcyxutOS/RJE2E77U/E45s=",
      "url": "css/imported/Katex/fonts/KaTeX_Size2-Regular.ttf"
    },
    {
      "hash": "sha256-IBTFI8MhC8wWZkjE1MxX8Ft0ffB6JCd79xxR5n3Hnj0=",
      "url": "css/imported/Katex/fonts/KaTeX_Size2-Regular.woff"
    },
    {
      "hash": "sha256-0ExUIZ+ersbU1P1C37KHhZdaR5TWsvxx5Wa5zW24Qt0=",
      "url": "css/imported/Katex/fonts/KaTeX_Size2-Regular.woff2"
    },
    {
      "hash": "sha256-UA4E1U8NUWZjMsnSCJqoA74iqoeOylOeWfpTxuUisII=",
      "url": "css/imported/Katex/fonts/KaTeX_Size3-Regular.ttf"
    },
    {
      "hash": "sha256-ara2Lpti2uLADdkPeRvRCVC+Dsw0kNfWBF9Rwuj+CUk=",
      "url": "css/imported/Katex/fonts/KaTeX_Size3-Regular.woff"
    },
    {
      "hash": "sha256-c9WRJxsWBJYMsQu5D+4CFnCvcpcBfg6YSAszLRH1GZU=",
      "url": "css/imported/Katex/fonts/KaTeX_Size3-Regular.woff2"
    },
    {
      "hash": "sha256-xkc2fR3U4WJGhxfQIOH8Dx3Fwm6/3/vlUmFxO/iMWHc=",
      "url": "css/imported/Katex/fonts/KaTeX_Size4-Regular.ttf"
    },
    {
      "hash": "sha256-mfnGdQtInJRivwSQC9P5Od+bgpM52qqqme9Ulc3d6lg=",
      "url": "css/imported/Katex/fonts/KaTeX_Size4-Regular.woff"
    },
    {
      "hash": "sha256-pK99QURAocF5CCXPtwDPnPQ7DyxLBPDrxSMBGtmFPsA=",
      "url": "css/imported/Katex/fonts/KaTeX_Size4-Regular.woff2"
    },
    {
      "hash": "sha256-8B8+h9nGphwMCBzrV3q9hk6wCmEvesFiDdaRX60u9ao=",
      "url": "css/imported/Katex/fonts/KaTeX_Typewriter-Regular.ttf"
    },
    {
      "hash": "sha256-4U/tArGrp86fWv1YRLXQMhsiNR/rxyDg3ouHI1J2Cfc=",
      "url": "css/imported/Katex/fonts/KaTeX_Typewriter-Regular.woff"
    },
    {
      "hash": "sha256-cdUX1ngneHz6vfGGkUzDNY7aU543kxlB8rL9SiH2jAs=",
      "url": "css/imported/Katex/fonts/KaTeX_Typewriter-Regular.woff2"
    },
    {
      "hash": "sha256-Gc1qeEmHPlrh2gJAbRSmr+E592K6LoqyLOfshXV08BA=",
      "url": "css/imported/MudBlazor/Roboto.css"
    },
    {
      "hash": "sha256-McWWInTYvTHL9y9FqqYV8z8jAIhJG07l2fVE/vEMQY4=",
      "url": "css/imported/MudBlazor/src/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3-UBGEe.woff2"
    },
    {
      "hash": "sha256-2UzKt0AF6mMsVoDTPTRYZjTe1ZUDWZD6LP7y8eHMy1U=",
      "url": "css/imported/MudBlazor/src/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3CUBGEe.woff2"
    },
    {
      "hash": "sha256-Oo7ugxK3esLvLcLgH93fjt6KT3K/GgjUB0XYtDI4b98=",
      "url": "css/imported/MudBlazor/src/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3GUBGEe.woff2"
    },
    {
      "hash": "sha256-iEkz+1eJtHjS2mikywvVzBONmV8f6pqVe6Kcs8APG/c=",
      "url": "css/imported/MudBlazor/src/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3KUBGEe.woff2"
    },
    {
      "hash": "sha256-OMpoBS32u3ISb/nO3X140q/mIHnpFJ3e32UK6PTHRM8=",
      "url": "css/imported/MudBlazor/src/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3OUBGEe.woff2"
    },
    {
      "hash": "sha256-wGyj/LxffDfrt8hqaVAgCZEezYGDgRuuAvmx+7BUHds=",
      "url": "css/imported/MudBlazor/src/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3iUBGEe.woff2"
    },
    {
      "hash": "sha256-ILU1+oDIGJ47h9GAMDg4mWAgOohtUCvC7xhXr/wvONI=",
      "url": "css/imported/MudBlazor/src/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3yUBA.woff2"
    },
    {
      "hash": "sha256-11joU1KXHf/lGlmSQF64+bMWsb7YJJVEXDKGme5ACDA=",
      "url": "css/imported/MudBlazor/src/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMawCUBGEe.woff2"
    },
    {
      "hash": "sha256-6SF4VJbtLZjCJXyIpvg4r6asvuBcuEZwSFAb/iowFGE=",
      "url": "css/imported/MudBlazor/src/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMaxKUBGEe.woff2"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-91+xBt7UUOLbS6bRVJRIYL+1wYRmYHOhuMXlEhKz+Z8=",
      "url": "index.html"
    },
    {
      "hash": "sha256-iwxbnSzF9/KIXQv2ngVGYkTyk5Uz6D50Pi88jr+MERQ=",
      "url": "js/BrotliModule.js"
    },
    {
      "hash": "sha256-n8JqbVqXP608pyu0PQ0M7znaAsA1Tqheho64a6C0jMI=",
      "url": "js/KaTeX.cs.js"
    },
    {
      "hash": "sha256-zG/WsT2Hoo/vrfSbaf/rSEIAIzIp8AKcemlaX45B2u4=",
      "url": "js/PWAService.cs.js"
    },
    {
      "hash": "sha256-sMlf1RhvrHWE5u5ol+FEw4t6ETbSo6w6HsKdaTA5lPE=",
      "url": "js/Uni.js"
    },
    {
      "hash": "sha256-DZaFwVQD04A5i6qfWiT4LPqs8CZS6EEVhAW2LDKJbMI=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-Y00NreS8QvkVJ/0jwpIn0ojYkqkUMLCnGQhUoQE2dBc=",
      "url": "resources/AzerDil.json"
    },
    {
      "hash": "sha256-IVOgJnFhyiy+Sd0V3IaEoUnkS77ieRdQc9EeEbxXJGw=",
      "url": "resources/Biznes.json"
    },
    {
      "hash": "sha256-4+wvfMHaRL14IzWsC11sNwJOzKRY09+oY5KTqlkiI10=",
      "url": "resources/DifferentialEquations.json"
    },
    {
      "hash": "sha256-fs4ZRkmb/gP9Z7sK1gzEIXpPhYW3w1WPEFhu6vO3wvw=",
      "url": "resources/Eng.json"
    },
    {
      "hash": "sha256-vYkTBuxjNAEER8ANX26ikiY9v4BjTch4g4qD6izyaZE=",
      "url": "resources/FunOfIT.json"
    },
    {
      "hash": "sha256-oBwLpSvHxWFkE7TnLWCFSD7/g3y5IPT9bQ4zOGcV4qA=",
      "url": "resources/Ginekologiya.json"
    },
    {
      "hash": "sha256-ntv/VzbcruNmk7axvSOCNlpcB2af1Toq+zFwJssQqtE=",
      "url": "resources/History.json"
    },
    {
      "hash": "sha256-aPk/vr0K2ymRMybbjexal0NhPcuGq49kwoqYZBGWejc=",
      "url": "resources/Inform.json"
    },
    {
      "hash": "sha256-oWdoHriH0up4eD63WrQSjSgAM4yJ2FQLSQDFJY++PO8=",
      "url": "resources/LinearAlgebra.json"
    },
    {
      "hash": "sha256-h97YAwk+FFfqSsWtDkRzr+xz5ubK1tgRYmnMRXGGW8c=",
      "url": "resources/Math.json"
    },
    {
      "hash": "sha256-mMzjMmXxwFaJ4hTUiMcvTP5fcg8S36b0RyZ+f7vyVMI=",
      "url": "resources/Physics.json"
    },
    {
      "hash": "sha256-QxYaEm+6UI8l6rj99AJ3i7/7rOaQ1VQs3CH4NuSwr6s=",
      "url": "resources/Programming.json"
    },
    {
      "hash": "sha256-GMayAI8sgZ8QdNCvqR5pLd71pQStfbFvTlMQdl7Tgnw=",
      "url": "resources/Vusala.json"
    }
  ]
};
