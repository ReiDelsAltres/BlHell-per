self.assetsManifest = {
  "version": "eTJ23n5P",
  "assets": [
    {
      "hash": "sha256-RZaJo+IYciR1DekP2t+tvrQ39NXbGGlOzWX2EIHSlic=",
      "url": "BlHell-per.styles.css"
    },
    {
      "hash": "sha256-n8JqbVqXP608pyu0PQ0M7znaAsA1Tqheho64a6C0jMI=",
      "url": "KaTeX.cs.js"
    },
    {
      "hash": "sha256-xIq0ustLrUFLaAS+c/Lq2ebq/D+LIkopuBXo2P9peAI=",
      "url": "Pages/Constructor.razor.js"
    },
    {
      "hash": "sha256-qbO919CAYK4kRxWDRW3CehclkGcaxvcdMilLG4sKVe8=",
      "url": "_content/BlazorAnimation/animate.css"
    },
    {
      "hash": "sha256-+t/o5a1+4WbQxhoZypQHhvyATOlNrCBf5wRvVZ3/lrU=",
      "url": "_content/BlazorAnimation/blazorAnimationInterop.js"
    },
    {
      "hash": "sha256-PtApvXsjtN3h6TrGmJjCQsaFMN/pyLARBUCEQhLn7Oc=",
      "url": "_content/BlazorDownloadFile/BlazorDownloadFileScript.js"
    },
    {
      "hash": "sha256-Hh7BRmiYuRD1Lq8ZF9jVWOOJuN3tWPS5M2lLZzuayjw=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-weSY1+xC2IWsc4ncUHtQhWp3H5eek/LVHZEDlWdgryY=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-yEpb3vXc7l7/qmiEWUNfWHN9EnLRY7PddqDP9utPlpg=",
      "url": "_content/Toolbelt.Blazor.FileDropZone/script.min.js"
    },
    {
      "hash": "sha256-rN9ebccf1yzi+bWyyip51JJuAKONWUHDBKWnKUpDWAA=",
      "url": "_content/Toolbelt.Blazor.GetProperty.Script/Toolbelt.Blazor.GetProperty.Script.lib.module.js"
    },
    {
      "hash": "sha256-JZKSAzXaVyR6R/N5hGGmDT8N6YzLT40zEimfUFGY2tE=",
      "url": "_framework/BlHell-per.545hmyka9t.wasm"
    },
    {
      "hash": "sha256-m4taEdRaJngG6jpisyMLHOUJsXhap7M+KbFnI4iqT2w=",
      "url": "_framework/BlazorAnimation.3mgu0rp8fb.wasm"
    },
    {
      "hash": "sha256-ZqFE/7nYSXyRqxyYXOinHc3jZEeP5EyOdWKbY/U4/lY=",
      "url": "_framework/BlazorDownloadFile.yq1vsevvip.wasm"
    },
    {
      "hash": "sha256-IYomHY+GQitl47ydpgv42kDmWAStJKBFsw3XVJYuPQY=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.57634tzs3y.wasm"
    },
    {
      "hash": "sha256-pMOeQfmqf22TqkpioUt3RsA0B198t2eSyJ8jLboYEmw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.cghgwo04xe.wasm"
    },
    {
      "hash": "sha256-avvjER2v436c2qXr7uDoi0haIY387E5nqDxdlziaTL0=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.y546m1fxt5.wasm"
    },
    {
      "hash": "sha256-UqAZflcFvNCUyhfuVVRWjfHWNs3OO4ayX80FBhU+a1s=",
      "url": "_framework/Microsoft.AspNetCore.Components.muqfe7a5c8.wasm"
    },
    {
      "hash": "sha256-xkcQrK8ImCF187jUK1rMdn2iz9TjglbXi/UBKpzHd4Q=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.68iize6zgo.wasm"
    },
    {
      "hash": "sha256-vzFvc6UElTC0RG8Ga9PszNl2ctNS+7GB11SCS+NxDA8=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.x4dnkuqbs4.wasm"
    },
    {
      "hash": "sha256-/RFhEMqX+Ut3f9alN/56gKt5BzpPr11oJpOssyKvLV8=",
      "url": "_framework/Microsoft.Extensions.Configuration.xrlvup7x8q.wasm"
    },
    {
      "hash": "sha256-U65eWGgSCmNQfzbawOCU0URFHa4ZErYf9uXJ3X0WDtg=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.r6uuu3nih3.wasm"
    },
    {
      "hash": "sha256-t0V/HqX56uPS46TIANcPhdnOA1JC2I1JjmKOJkwo/N4=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.pgrterz1sz.wasm"
    },
    {
      "hash": "sha256-c29RmalAkIt6iWvUr31OkflYCKyzyO6vyplry2MXz1I=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.f105w8ezv4.wasm"
    },
    {
      "hash": "sha256-6+hWNu6IOJjQ2Q0U7rYk73IzqF8az4duNUgL24LiFUo=",
      "url": "_framework/Microsoft.Extensions.Localization.h5tijc5bhn.wasm"
    },
    {
      "hash": "sha256-b3ehbZeOVmM/wZsYusPkWLPnjXeR6yuvCHT0i24+bL8=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.fwy3cu6azc.wasm"
    },
    {
      "hash": "sha256-x0Vhvwosytm+v/zajeOz8oxeyoAnldEw2EIiIcyscWo=",
      "url": "_framework/Microsoft.Extensions.Logging.l18u2dyece.wasm"
    },
    {
      "hash": "sha256-4omL9W6873ABA9+A1BEw/KDzM4VQFqruUKKgtBPKSHI=",
      "url": "_framework/Microsoft.Extensions.Options.eptal0ejc7.wasm"
    },
    {
      "hash": "sha256-gVPOd9w66y13NCCmIa1bYqHFeVQwixStiqBGlzMoIrc=",
      "url": "_framework/Microsoft.Extensions.Primitives.t9ayv3wa7d.wasm"
    },
    {
      "hash": "sha256-wvxIVdGczglw/Q5hyewNxutDbog+f8mbTZy/8TkR70I=",
      "url": "_framework/Microsoft.JSInterop.2shby7jjex.wasm"
    },
    {
      "hash": "sha256-WuuQXW1+AnPHafZKt7ukqmwRDrGYbEV2LhxNuPl+ybo=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.y1ydbrr1bj.wasm"
    },
    {
      "hash": "sha256-J+pGsTDI7vxp2mTy7vr7iSsby/hdxiKRMgGu3TcE4y0=",
      "url": "_framework/MudBlazor.vyk8izhcsu.wasm"
    },
    {
      "hash": "sha256-ovh1mKpIvmbImlz9SJ/ojx8helrts3/R/cDrWltmu+U=",
      "url": "_framework/System.Collections.Concurrent.muxkzvc2fw.wasm"
    },
    {
      "hash": "sha256-0kbljsEgfoYTRINqK3x6AKpn8Wa8WnolC8H6kixFQr8=",
      "url": "_framework/System.Collections.Immutable.uh9fx69562.wasm"
    },
    {
      "hash": "sha256-XBCuoRXECUz95efTFOufbqURPT6we0D16lq9mCrt21E=",
      "url": "_framework/System.Collections.NonGeneric.kgter2i0fk.wasm"
    },
    {
      "hash": "sha256-wYnkk+LkNfu/jaSJ+0zGHpBNzVD+HiTlXbqm/OXeTHQ=",
      "url": "_framework/System.Collections.Specialized.3bfjm7x10c.wasm"
    },
    {
      "hash": "sha256-8szdzdf1tseQEstQQBv3w165WTA1dzSNYOoN1Kep0jw=",
      "url": "_framework/System.Collections.alh8gytq1k.wasm"
    },
    {
      "hash": "sha256-3CixNi+y6GjkQcRObFpTjTsLZG3TJ/2cA9+Sn4upG2Y=",
      "url": "_framework/System.ComponentModel.Annotations.wx60o7i02b.wasm"
    },
    {
      "hash": "sha256-Kp4tMv6iWudePTE3plxwbc3BzB7FhaURPJByRVQu8GI=",
      "url": "_framework/System.ComponentModel.Primitives.acf2w9gw7a.wasm"
    },
    {
      "hash": "sha256-gWF2IFVPVRXOijyOTXeuaeRpUySG1XyK1Xo5+kkXw9E=",
      "url": "_framework/System.ComponentModel.TypeConverter.jba9ae4qb1.wasm"
    },
    {
      "hash": "sha256-R7ngh95V/nsqhrCHW2rk39aNArmqdfwpXE4RTI+u4Kk=",
      "url": "_framework/System.ComponentModel.fmqia21jk3.wasm"
    },
    {
      "hash": "sha256-OIzg7F8IgmhWuLO9VJK6xJBxF0f18ZrULUal3fNBhbg=",
      "url": "_framework/System.Console.84imfan5o7.wasm"
    },
    {
      "hash": "sha256-whyzcL1P8L3ltQSvkT2XbVhhQSZpboWwyBv5UQew4qk=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.2b7xw4pwq3.wasm"
    },
    {
      "hash": "sha256-Tgo2Bvw69iSN6s09Sf8jKXeGkzSmVcbtTucMXDaa3s0=",
      "url": "_framework/System.IO.Pipelines.24qyxv6lkc.wasm"
    },
    {
      "hash": "sha256-4KLfjl8UhwPsF+Y4NDolVaS8f2PJXaIzaO4ElU9nU2I=",
      "url": "_framework/System.Linq.Expressions.ch7tqy78o9.wasm"
    },
    {
      "hash": "sha256-UCeMrN0BzIAbm2557moFAMDkCIJYALbn+ERK6iKv1sI=",
      "url": "_framework/System.Linq.gspndan17x.wasm"
    },
    {
      "hash": "sha256-3ILU50dDPR5FIeUIYveuh1j9FjUPOmkqksLo4EYdwCg=",
      "url": "_framework/System.Memory.kyou98620v.wasm"
    },
    {
      "hash": "sha256-xqtGzV3rpbdL+WotMI6reS27cPHEQXBTxHET8/Ancks=",
      "url": "_framework/System.Net.Http.uyij5s3yxn.wasm"
    },
    {
      "hash": "sha256-aG15T3L86fhpgjCoMvCS6FO69rY1GDmsonZcREhqUJs=",
      "url": "_framework/System.Net.Primitives.cbhvw57pgn.wasm"
    },
    {
      "hash": "sha256-kKUcOexnX2OgYycf49y7Xt+o3lJYAL38MJ2njtZXymo=",
      "url": "_framework/System.ObjectModel.o6c7xszh1x.wasm"
    },
    {
      "hash": "sha256-Y+7geVvX8pBniUf90CoD2XWzUFdWE+F6asZD0gwZ1hg=",
      "url": "_framework/System.Private.CoreLib.jcao44lh4v.wasm"
    },
    {
      "hash": "sha256-jRv7oW+MMQWXgutv8nhC9XLTIMmJ4Yii8s0D0MWQTdQ=",
      "url": "_framework/System.Private.Uri.rq7xrp8z4k.wasm"
    },
    {
      "hash": "sha256-MhqdWhoi3KT7iPZ7uP2ff9n5bQPV+0hIXkQkVek/ynA=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.u8hag84oqs.wasm"
    },
    {
      "hash": "sha256-gRcUoUaWnrycPP5O0eTJ2PNSqLhg2xkThMlumnhPdic=",
      "url": "_framework/System.Runtime.Serialization.Primitives.zzbbz56duj.wasm"
    },
    {
      "hash": "sha256-Uc6GlGtprg9i3LHklaQZFGZru1FHgcRjf3JmMF+3B9g=",
      "url": "_framework/System.Runtime.xsg1zkv0t8.wasm"
    },
    {
      "hash": "sha256-OSOxjPaZjjeLdDPiFKQ+wLS+uio5UbJAG09WPwJ4f5U=",
      "url": "_framework/System.Text.Encodings.Web.3pcaqdhr6n.wasm"
    },
    {
      "hash": "sha256-BgkfT10TkHT6vum30ksbOGcUK93h2Bt0IQXoPCAr/FI=",
      "url": "_framework/System.Text.Json.m1csbc30y1.wasm"
    },
    {
      "hash": "sha256-TCv3pk0t68Ptj2IW+lIiAY8ZlCKKqNETUvHJgPXQq0Q=",
      "url": "_framework/System.Text.RegularExpressions.orxf0v69p4.wasm"
    },
    {
      "hash": "sha256-pkAEiU7m4RDszmKQ025rjAa3Xy+zeQ7UZYl29D7ksFQ=",
      "url": "_framework/System.Threading.Tasks.Extensions.6xr06rmzc2.wasm"
    },
    {
      "hash": "sha256-ViNRvhyxlTugIlqJHamw/HwbXlg/YWcrANmxuTM0tfg=",
      "url": "_framework/System.ezrw3d5kw2.wasm"
    },
    {
      "hash": "sha256-PJoTW9T0nomxyrLiHdYz1k4uFFnCMX+JLVip73ItWG4=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-0C5th70x3cgwI6otbYfnZFNKiDFUEWeeGoJEdszlFRc=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-5l9l4YIatg6qFeQn0hqBaGjQ2csGanJ19Dl0MxcvMXw=",
      "url": "_framework/dotnet.native.a01w7jk8nk.wasm"
    },
    {
      "hash": "sha256-gDHgoHZPLFxeFwOPtQH3QDzKCs3HkKM9Xjmoc4V09z0=",
      "url": "_framework/dotnet.native.gwrl96b288.js"
    },
    {
      "hash": "sha256-kTZbe5ESp04VMT22TnjRmFj88VbtEcohZfCm4og/IDw=",
      "url": "_framework/dotnet.runtime.5nhp1wfg9b.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-8HjdiUxOi8AZ52n0Ehrd5OEislB0NBNsqx55avSMOQU=",
      "url": "_framework/netstandard.g8wjv8robi.wasm"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-z8OR40MowJ8GgK6P89Y+hiJK5+cclzFHzLhFQLL92bg=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-myltxrknUVoInGTPoh3wTCqm8kbZJ1QpqcQC76q1Q2Y=",
      "url": "css/extended.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-QNUkGIfrD0/d8grqrrEHfhUUu26V7ZrCBUG6DhhZi3E=",
      "url": "index.html"
    },
    {
      "hash": "sha256-DZaFwVQD04A5i6qfWiT4LPqs8CZS6EEVhAW2LDKJbMI=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-Y00NreS8QvkVJ/0jwpIn0ojYkqkUMLCnGQhUoQE2dBc=",
      "url": "resources/AzerDil.json"
    },
    {
      "hash": "sha256-IVOgJnFhyiy+Sd0V3IaEoUnkS77ieRdQc9EeEbxXJGw=",
      "url": "resources/Biznes.json"
    },
    {
      "hash": "sha256-WiJtzU+6HXyMPKwmF8YBZ1mHz/Lo/mJLx67b8DL+Z+g=",
      "url": "resources/DifferentialEquations.json"
    },
    {
      "hash": "sha256-X4c/jlHJ4jZL7gzP3KjaSSYKLIdvyDxw1CX/qEB1bPA=",
      "url": "resources/Eng.json"
    },
    {
      "hash": "sha256-vYkTBuxjNAEER8ANX26ikiY9v4BjTch4g4qD6izyaZE=",
      "url": "resources/FunOfIT.json"
    },
    {
      "hash": "sha256-oBwLpSvHxWFkE7TnLWCFSD7/g3y5IPT9bQ4zOGcV4qA=",
      "url": "resources/Ginekologiya.json"
    },
    {
      "hash": "sha256-ntv/VzbcruNmk7axvSOCNlpcB2af1Toq+zFwJssQqtE=",
      "url": "resources/History.json"
    },
    {
      "hash": "sha256-aPk/vr0K2ymRMybbjexal0NhPcuGq49kwoqYZBGWejc=",
      "url": "resources/Inform.json"
    },
    {
      "hash": "sha256-QrTVhd9V49x8mFqI9q7ZdNsc2JE4xzTaf0khe9r4Sbc=",
      "url": "resources/LinearAlgebra.json"
    },
    {
      "hash": "sha256-h97YAwk+FFfqSsWtDkRzr+xz5ubK1tgRYmnMRXGGW8c=",
      "url": "resources/Math.json"
    },
    {
      "hash": "sha256-mMzjMmXxwFaJ4hTUiMcvTP5fcg8S36b0RyZ+f7vyVMI=",
      "url": "resources/Physics.json"
    },
    {
      "hash": "sha256-5MPAJd3VKHr3TtXQpw6JJjbWoUrcdHcHdEaef+gjEY8=",
      "url": "resources/Programming.json"
    },
    {
      "hash": "sha256-GMayAI8sgZ8QdNCvqR5pLd71pQStfbFvTlMQdl7Tgnw=",
      "url": "resources/Vusala.json"
    }
  ]
};
